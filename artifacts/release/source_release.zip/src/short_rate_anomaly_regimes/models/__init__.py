"""Asset-pricing estimators."""
