"""Data acquisition and validation."""
