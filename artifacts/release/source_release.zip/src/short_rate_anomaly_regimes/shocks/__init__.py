"""Monetary-policy shock decomposition."""
