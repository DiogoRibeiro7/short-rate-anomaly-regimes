# Validation

Latest validation was performed on 31 July 2026 from the repository checkout on Windows with Python 3.13.5.

## Passed checks

- `poetry check`
- `poetry run ruff check .`
- `poetry run ruff format --check .`
- `poetry run mypy src tests scripts`
- `poetry run python scripts/verify_title.py`
- `poetry run python scripts/verify_manuscript.py`
- `poetry run srar validate-config --config configs/baseline.yaml`
- `poetry run srar validate-config --config configs/extensions.yaml`
- `poetry run srar validate-config --config configs/regimes.yaml`
- `poetry run srar validate-config --config configs/reporting.yaml`
- `poetry run srar validate-data --registry configs/data_sources.yaml`
- `poetry run srar acquire-data --registry configs/data_sources.yaml`
- `poetry run srar build-catalog --registry configs/data_sources.yaml`
- `poetry run srar release-audit`
- `poetry run pytest` with `--cov-fail-under=95`
- `poetry run pre-commit run --all-files`

The current test suite contains 227 tests. All 227 passed. The measured scaffold coverage is 95.60 percent because milestone-specific estimators and data clients are intentionally represented by explicit gates until their evidence inputs are completed.

## Current quality status

- The package metadata passes `poetry check`.
- The dependency graph is locked in `poetry.lock`.
- Ruff linting and formatting pass under the repository configuration.
- Strict mypy passes for `src` and `tests`, with an explicit override for untyped `statsmodels` imports.
- Pytest imports from the `src` layout without requiring a manual `PYTHONPATH`.
- GitHub Actions runs the same metadata, lint, format, type-check, and test gates on `main` and `develop`.
- `make check` now includes YAML project-config validation and source-registry validation.
- `make check` now exercises data-acquisition dry-run planning and DuckDB catalog creation.
- `make env-manifest` writes `artifacts/environment/manifest.json` with Python, OS, package, BLAS, Git, and config-hash metadata.
- Portfolio parser, validation, manifest, and synthetic reconstruction tests cover the Milestone 4 test-asset assembly layer.
- First-pass time-series tests cover excess-return construction, date alignment accounting, Newey-West OLS inference, independent matrix-HAC verification, diagnostics, and artifact writers.
- Cross-sectional pricing tests cover OLS, GLS, Fama-MacBeth, Shanken-style corrected uncertainty, weak-factor warnings, leave-one-group systems, GRS diagnostics, simulation recovery, model evaluation tables, and artifact writers.
- Replication-audit tests cover table-target loading, frozen tolerance comparison, allowed status labels, missing-input audit rows, JSON/CSV outputs, standalone baseline-only report sections, and the complete audit-table appendix.
- Robustness tests cover weak-factor rank and singular-value diagnostics, beta dispersion, factor spanning, irrelevant-factor flags, Holm correction within robustness families, economic-change flags, predeclared robustness classification, and blocked report generation.
- Temporal-extension tests cover locked-vintage panel assembly, revised-history audits, reduced extension universes, December 2013 frozen-parameter pricing errors, pre/post pattern diagnostics, expanding and rolling window schedules, boundary figures, and blocked report generation.
- Monetary-regime tests cover verified regime tables, boundary-shift sensitivity, split-sample eligibility, pooled regime interactions, joint Wald tests, Chow and Quandt-Andrews breaks, Bai-Perron-style multiple-break selection, CUSUM diagnostics, Holm correction, stability classification, figures, and blocked report generation.
- Shock-decomposition tests cover event-level policy/information/ambiguous component preservation, no-meeting monthly aggregation, multiple-meeting flags, source-study summary audits, asset-pricing shock specifications, spanning correlations, policy-language enforcement, output writing, and blocked report generation.
- Out-of-sample tests cover frozen refit schedules, no-lookahead model forecasts, historical-mean and zero-return benchmarks, forecast vintages, RMSE/MAE/max-error/OOS-R2/rank metrics, top-minus-bottom rank accuracy, transparent model-confidence sets, output writing, and blocked report generation.
- Manuscript tests cover title punctuation, numeric-claim artifact mappings, declared artifact existence, restricted causal-language sections, empirical-paragraph context declarations, table/figure artifact sources, blocked manuscript reports, and the repository manuscript validation script.
- Release tests cover restricted-path filtering, processed-data redistribution warnings, sanitized environment manifests, Poetry-lock SBOM generation, checksum filtering, deterministic source archives, archive manifests, data-acquisition guide rendering, release-gate severity, release notes, adversarial reports, and the release-audit CLI.

## Scientific status

No empirical replication result has been produced. The final article and supplement are present locally and hashed, but strict replication remains blocked until exact source versions and required raw inputs are legally obtained and registered. The adversarial release gate has no critical restricted-path findings, but empirical-results release is blocked by one major missing-input issue. The codebase must use the documented reconstruction label whenever an original input cannot be obtained.
